sleep 10s

/opt/mssql-tools/bin/sqlcmd -S localhost -U root -P root -i init-db.sql

