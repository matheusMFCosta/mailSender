export type databaseTables = "ACCOUNT" | "EMAILTEMPLATE" | "LOG"
